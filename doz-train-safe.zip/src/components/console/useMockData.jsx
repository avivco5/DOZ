import { useState, useEffect, useRef, useCallback } from "react";

const ARENA = { minX: 0, maxX: 100, minY: 0, maxY: 60 };

const OBSTACLE_SEED = [
  { id: "obs-01", x: 40, y: 30, w: 6, h: 4, type: "barrier" },
  { id: "obs-02", x: 70, y: 15, w: 3, h: 3, type: "pillar" },
  { id: "obs-03", x: 20, y: 45, w: 5, h: 5, type: "barrier" },
  { id: "obs-04", x: 55, y: 50, w: 4, h: 3, type: "pillar" },
  { id: "obs-05", x: 85, y: 35, w: 7, h: 2, type: "barrier" },
  { id: "obs-06", x: 15, y: 25, w: 3, h: 6, type: "barrier" },
  { id: "obs-07", x: 60, y: 8, w: 4, h: 4, type: "pillar" },
  { id: "obs-08", x: 35, y: 55, w: 5, h: 3, type: "barrier" },
  { id: "obs-09", x: 80, y: 50, w: 3, h: 3, type: "pillar" },
  { id: "obs-10", x: 50, y: 25, w: 8, h: 2, type: "barrier" },
];

const PLAYER_NAMES = ["Alpha-1", "Bravo-2", "Charlie-3", "Delta-4", "Echo-5", "Foxtrot-6"];

function clamp(v, min, max) { return Math.max(min, Math.min(max, v)); }
function randBetween(a, b) { return a + Math.random() * (b - a); }

function createInitialPlayers() {
  return PLAYER_NAMES.map((name, i) => ({
    player_id: i + 1,
    name,
    x: randBetween(5, 95),
    y: randBetween(5, 55),
    z: 0,
    yaw_deg: Math.random() * 360,
    battery_v: +(3.5 + Math.random() * 0.5).toFixed(2),
    quality: +(0.7 + Math.random() * 0.3).toFixed(2),
    packet_rate_hz: Math.round(15 + Math.random() * 10),
    last_seen_ms: Date.now(),
    drops: { bad_crc: Math.floor(Math.random() * 3), rate_limited: Math.floor(Math.random() * 2) },
    alert_state: { active: false, level: "none", reason: "" },
    connected: true,
  }));
}

export default function useMockData() {
  const [players, setPlayers] = useState(() => createInitialPlayers());
  const [obstacles] = useState(OBSTACLE_SEED);
  const [events, setEvents] = useState([]);
  const [recording, setRecording] = useState({ active: false, session_id: null, start_ts_ms: null, output_dir: null });
  const [systemStatus, setSystemStatus] = useState("OK");
  const [wsConnected, setWsConnected] = useState(true);
  const trailsRef = useRef({});
  const [trails, setTrails] = useState({});
  const tickRef = useRef(0);

  const addEvent = useCallback((evt) => {
    setEvents(prev => [evt, ...prev].slice(0, 200));
  }, []);

  // Simulate player movement
  useEffect(() => {
    const interval = setInterval(() => {
      tickRef.current++;
      const now = Date.now();

      setPlayers(prev => prev.map(p => {
        if (!p.connected) return p;

        const dx = (Math.random() - 0.5) * 2;
        const dy = (Math.random() - 0.5) * 2;
        const newX = clamp(p.x + dx, 1, 99);
        const newY = clamp(p.y + dy, 1, 59);
        const newYaw = (p.yaw_deg + (Math.random() - 0.5) * 20 + 360) % 360;

        // Occasional alert
        let alertState = { ...p.alert_state };
        if (tickRef.current % 50 === 0 && Math.random() > 0.7) {
          const nowActive = !alertState.active;
          alertState = {
            active: nowActive,
            level: nowActive ? (Math.random() > 0.5 ? "warning" : "caution") : "none",
            reason: nowActive ? "direction" : "",
          };
          addEvent({
            ts_ms: now,
            level: nowActive ? "warn" : "info",
            event: nowActive ? "alert_on" : "alert_off",
            player_id: p.player_id,
            reason: nowActive ? "direction" : undefined,
          });
        }

        // Occasional drop
        let drops = { ...p.drops };
        if (Math.random() > 0.98) {
          const key = Math.random() > 0.5 ? "bad_crc" : "rate_limited";
          drops[key] = (drops[key] || 0) + 1;
          addEvent({
            ts_ms: now,
            level: "debug",
            event: "packet_dropped",
            player_id: p.player_id,
            reason: key,
          });
        }

        // Battery slow drain
        const batt = Math.max(3.0, p.battery_v - 0.0001);

        // Trail
        if (!trailsRef.current[p.player_id]) trailsRef.current[p.player_id] = [];
        trailsRef.current[p.player_id].push({ x: newX, y: newY });
        if (trailsRef.current[p.player_id].length > 60) trailsRef.current[p.player_id].shift();

        return {
          ...p,
          x: newX,
          y: newY,
          yaw_deg: newYaw,
          battery_v: +batt.toFixed(2),
          quality: +(0.7 + Math.random() * 0.3).toFixed(2),
          packet_rate_hz: Math.round(15 + Math.random() * 10),
          last_seen_ms: now,
          drops,
          alert_state: alertState,
        };
      }));

      setTrails({ ...trailsRef.current });

      // Occasional disconnect/reconnect
      if (tickRef.current % 80 === 0) {
        setPlayers(prev => {
          const idx = Math.floor(Math.random() * prev.length);
          const p = prev[idx];
          const newConnected = !p.connected;
          addEvent({
            ts_ms: now,
            level: newConnected ? "info" : "warn",
            event: newConnected ? "player_connected" : "player_disconnected",
            player_id: p.player_id,
          });
          return prev.map((pp, i) => i === idx ? { ...pp, connected: newConnected, last_seen_ms: newConnected ? now : pp.last_seen_ms } : pp);
        });
      }
    }, 200);

    // Initial events
    const now = Date.now();
    PLAYER_NAMES.forEach((_, i) => {
      addEvent({ ts_ms: now - 1000 + i * 100, level: "info", event: "player_connected", player_id: i + 1 });
    });

    return () => clearInterval(interval);
  }, [addEvent]);

  const startRecording = useCallback(() => {
    const sessionId = `REC-${Date.now().toString(36).toUpperCase()}`;
    setRecording({ active: true, session_id: sessionId, start_ts_ms: Date.now(), output_dir: `/tmp/aar/${sessionId}` });
    addEvent({ ts_ms: Date.now(), level: "info", event: "recording_start", details: sessionId });
  }, [addEvent]);

  const stopRecording = useCallback(() => {
    const prev = recording;
    setRecording({ active: false, session_id: null, start_ts_ms: null, output_dir: null });
    addEvent({ ts_ms: Date.now(), level: "info", event: "recording_stop", details: prev.session_id });
    return { session_id: prev.session_id, files: [`${prev.output_dir}/world.jsonl`, `${prev.output_dir}/events.jsonl`] };
  }, [recording, addEvent]);

  return {
    players,
    obstacles,
    events,
    recording,
    systemStatus,
    wsConnected,
    trails,
    arena: ARENA,
    startRecording,
    stopRecording,
  };
}